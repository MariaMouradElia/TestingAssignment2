public class EvenOrOdd {

    public String CheckIfEvenOrOdd(int a){
        if (a%2 == 0) return "Even";
        else          return "Odd";
    }
}
