import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MinMaxTest {

    MinMax MinMax = new MinMax();

    @Test
    public void array1(){
        int []a = {};
        assertEquals(-1,MinMax.isNumberMax(a));
        assertEquals(-1,MinMax.isNumberMin(a));
    }

    @Test
    public void array2(){
        int []a = {700,1000,99,-1,-10,500,47};
        assertEquals(1000,MinMax.isNumberMax(a));
        assertEquals(-10,MinMax.isNumberMin(a));
    }

}
