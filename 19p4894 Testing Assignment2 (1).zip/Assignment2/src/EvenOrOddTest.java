import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EvenOrOddTest {

    EvenOrOdd test = new EvenOrOdd();

    @Test
    public void IsZeroEven(){
        assertEquals("Even", test.CheckIfEvenOrOdd(0));
    }

    @Test
    public void fourIsEven(){
        assertEquals("Even", test.CheckIfEvenOrOdd(4));
    }

    @Test
    public void fortyIsEven(){
        assertEquals("Even", test.CheckIfEvenOrOdd(40));
    }

    @Test
    public void fiftyIsEven(){
        assertEquals("Even", test.CheckIfEvenOrOdd(50));
    }

    @Test
    public void oneIsOdd(){
        assertEquals("Odd", test.CheckIfEvenOrOdd(1));
    }

    @Test
    public void thirtyThreeIsOdd(){
        assertEquals("Odd", test.CheckIfEvenOrOdd(33));
    }

    @Test
    public void seventySevenIsOdd(){
        assertEquals("Odd", test.CheckIfEvenOrOdd(77));
    }

    @Test
    public void twentyThreeIsOdd(){
        assertEquals("Odd", test.CheckIfEvenOrOdd(23));

    }

}